package com.qa.TestCases;

import java.io.IOException;
import java.time.Duration;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.PageObjects.LoginPage;
import com.qa.Utilities.ReadExcel;

public class Excel_Login_TC_01 extends BaseTest {
	
	public static String Excel_Path = System.getProperty("user.dir")+"\\TestData\\TestDataSheet.xlsx"; 
	
	@DataProvider
	public Object[][] getData() throws InvalidFormatException {
		Object testData[][] = ReadExcel.getDataFromSheetSample(Excel_Path,"Sheet1");
		return testData;
	}
	
	

	@Test(dataProvider = "getData")
	public void Login(String user,String pass) throws IOException, InterruptedException {

		// Login
		
		LoginPage lp= new LoginPage(driver); // object creation
		
		lp.setUserName(user); //driven from Dataprovider-- Read Excel
		
		lp.setPassword(pass);
		
		Excel_Login_TC_01.Screenshot(driver);
		
		Thread.sleep(5000);
		
		lp.ClickLoginButton();
		
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		System.out.println(driver.getTitle());

		Excel_Login_TC_01.Screenshot(driver);

		Thread.sleep(5000);

	}

}

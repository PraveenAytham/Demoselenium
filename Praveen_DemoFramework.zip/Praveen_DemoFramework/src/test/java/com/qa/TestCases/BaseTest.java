package com.qa.TestCases;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.observer.ExtentObserver;

import com.aventstack.extentreports.reporter.ExtentReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import com.aventstack.extentreports.reporter.configuration.Theme;
import com.qa.Utilities.ReadConfig;
import com.qa.Utilities.ReadData;

public class BaseTest {

	WebDriver driver;
	public static ExtentSparkReporter htmlReporter;
	public static ExtentReports extent;
	public static ExtentTest  test;


	ReadConfig rc = new ReadConfig();

	ReadData rdExcel = new ReadData();

	String URL = rc.getURL();
//	String UName =rc.getUsername();
//	String Pword = rc.getPassword();

	String UName = rdExcel.ExcelUsername();
	String Pword = rdExcel.ExcelPassword();

	String AccountNo = rc.getAccountNo();
	String Ammount = rc.getAmmount();
	String Desc = rc.getDesc();

	@BeforeSuite
	public void ExtentreportSetup() {

		 htmlReporter = new ExtentSparkReporter(System.getProperty("user.dir")+"\\MyOwnReport.html");
		 extent = new ExtentReports();
	     extent.attachReporter(htmlReporter);
	     
	     
	    extent.setSystemInfo("OS", "Windows");
	 	extent.setSystemInfo("HostName", "Selenium Batch");
	 	extent.setSystemInfo("Environment", "QA");
	 	extent.setSystemInfo("Author", "Praven Krishna");
	 			
	 	htmlReporter.config().setDocumentTitle("Selenium Report");
	 	htmlReporter.config().setReportName("My Own Report");
	 	htmlReporter.config().setTheme(Theme.STANDARD);


	}

	

	@BeforeMethod
	public void setup() {

		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Drivers\\chromedriver.exe");

		driver = new ChromeDriver();

		driver.get(URL);

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}

	@AfterMethod
	public void close(ITestResult result) throws IOException {

		if (result.getStatus() == ITestResult.FAILURE) {

			test.fail(" Testcase failed");
		} else if (result.getStatus() == ITestResult.SUCCESS) {

			test.pass(" Testcase Passed");
		} else {
			test.skip(" Testcase skipped");
		}

		driver.close();
	}

	@AfterSuite
	public void CloseReport() {
		extent.flush();
	}

	static void Screenshot(WebDriver driver) throws IOException {

		// Timestamp
		LocalDateTime currentTime = LocalDateTime.now();

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("ddMMyyyy_HHmmss");

		String Timestamp = dtf.format(currentTime);

		// Screenshot
		TakesScreenshot screenshot = ((TakesScreenshot) driver);

		File srcFile = screenshot.getScreenshotAs(OutputType.FILE);

		File destFile = new File(System.getProperty("user.dir")+"\\Screenshots\\Demo\\DemoGuru99_" + Timestamp + ".png");

		FileHandler.copy(srcFile, destFile);

	}

}

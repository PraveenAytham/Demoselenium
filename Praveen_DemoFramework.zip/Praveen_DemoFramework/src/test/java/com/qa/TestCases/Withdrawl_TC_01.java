package com.qa.TestCases;

import java.io.IOException;
import java.time.Duration;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.qa.PageObjects.LoginPage;
import com.qa.PageObjects.WithdrawlPage;

public class Withdrawl_TC_01 extends BaseTest {

	@Test
	public void withdrawl() throws IOException, InterruptedException {
		
		
		
		  test = extent.createTest("Withdrawl");
		  
		  test.assignCategory("Withdrawl Category");

		// Login
		LoginPage lp = new LoginPage(driver); // object creation

		lp.setUserName(UName);

		lp.setPassword(Pword);

		Withdrawl_TC_01.Screenshot(driver);

		lp.ClickLoginButton();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		System.out.println(driver.getTitle());

		Withdrawl_TC_01.Screenshot(driver);

		Thread.sleep(5000);

		// Withdrawl

		WithdrawlPage wp = new WithdrawlPage(driver);

		wp.clickWithdrawlTab();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		Thread.sleep(5000);

		wp.EnterAccountNo(AccountNo);

		wp.EnterAmount(Ammount);

		wp.EnterDescription(Desc);

		Withdrawl_TC_01.Screenshot(driver);

		wp.SubmitWithdrawl();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		Withdrawl_TC_01.Screenshot(driver);

		Thread.sleep(5000);


		
		Assert.assertTrue(true);
		


	}

}

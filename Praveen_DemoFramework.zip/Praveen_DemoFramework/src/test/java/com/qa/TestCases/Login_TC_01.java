package com.qa.TestCases;

import java.io.IOException;
import java.time.Duration;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.qa.PageObjects.LoginPage;

public class Login_TC_01 extends BaseTest {

	@Test
	public void Login() throws IOException, InterruptedException {
		
		
		  test = extent.createTest("Login");
		  
		 test.assignCategory("Login Category");

	     

		// Login

		LoginPage lp = new LoginPage(driver); // object creation

		lp.setUserName(UName); // driven from baseTest--> readData
		
		 test.log(Status.INFO, MarkupHelper.createLabel("Username entered", ExtentColor.BLUE));

		lp.setPassword(Pword);
		
		 test.log(Status.INFO, MarkupHelper.createLabel("Password entered", ExtentColor.ORANGE));

		Login_TC_01.Screenshot(driver);
		
		 test.log(Status.INFO, MarkupHelper.createLabel("Screenshot captured", ExtentColor.RED));

		Thread.sleep(5000);

		lp.ClickLoginButton();
		
		 test.log(Status.INFO, MarkupHelper.createLabel("Login button Clicked", ExtentColor.GREEN));
		 
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		System.out.println(driver.getTitle());
		
		test.log(Status.INFO, MarkupHelper.createLabel("Page Title fetched", ExtentColor.GREY));
		
		String Title= driver.getTitle();

		Login_TC_01.Screenshot(driver);
		
		test.log(Status.INFO, MarkupHelper.createLabel("Screenshot captured", ExtentColor.LIME));

		Thread.sleep(5000);

		Assert.assertTrue(true);
		
		
		//  Assert.assertEquals(Title, "Home Bank manager");

	}

}

package com.qa.TestCases;

import java.io.IOException;
import java.time.Duration;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.qa.PageObjects.LoginPage;
import com.qa.PageObjects.NewAccountPage;

public class NewAccount_TC_01 extends BaseTest {

	@Test
	public void NewAccount() throws IOException, InterruptedException {
		
		
		
		  test = extent.createTest("NewAccount");
		  
			 test.assignCategory("NewAccount Category");

//Login
		LoginPage lp = new LoginPage(driver); // object creation

		lp.setUserName(UName);

		lp.setPassword(Pword);

		NewAccount_TC_01.Screenshot(driver);

		lp.ClickLoginButton();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		System.out.println(driver.getTitle());

		NewAccount_TC_01.Screenshot(driver);

		Thread.sleep(5000);

//NewAccount		

		NewAccountPage nap = new NewAccountPage(driver);

		nap.clickNewAccountTab();

		nap.EnterCustomerId();

		nap.EnterInitialDeposit();

		Thread.sleep(5000);

		NewAccount_TC_01.Screenshot(driver);

		nap.AccountSubmit();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		NewAccount_TC_01.Screenshot(driver);

		Thread.sleep(5000);

		Assert.assertTrue(true);

	}

}

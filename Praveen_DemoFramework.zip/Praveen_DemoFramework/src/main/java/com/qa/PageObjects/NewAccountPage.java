package com.qa.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class NewAccountPage {
	WebDriver driver;
	
	
	
	public NewAccountPage(WebDriver TcDriver) {
			
		driver=TcDriver;
		
	}
	
	
	
	
	
	public void clickNewAccountTab() {
		
		
		WebElement NewAccountTab = driver.findElement(By.xpath("//a[text()=\"New Account\"]"));

		NewAccountTab.click();
		// Ad
		driver.get("https://demo.guru99.com/V4/manager/addAccount.php");
		
	}
	
	
	
	
	public void EnterCustomerId() {
		
		WebElement Customerid = driver.findElement(By.xpath("//input[@name=\"cusid\"]"));
		
		Customerid.sendKeys("29585");
	}
	
	
	
	
	public void EnterInitialDeposit() {
		
		WebElement InitialDeposit = driver.findElement(By.xpath("//input[@name=\"inideposit\"]"));
		
		InitialDeposit.sendKeys("5000");
		
		
	}
	
	
	public void AccountSubmit() {
		
		WebElement AccountSubmit = driver.findElement(By.xpath("//input[@value=\"submit\"]"));
		
		AccountSubmit.click();
		
	}

}

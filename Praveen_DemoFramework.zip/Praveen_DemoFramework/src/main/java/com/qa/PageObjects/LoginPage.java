package com.qa.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	
	WebDriver driver;
	
	
	public LoginPage(WebDriver Tcdriver) {   // constructor method
		
			driver=Tcdriver;
		
	}
	
	
	public void setUserName(String UName) {
		
		WebElement userName = driver.findElement(By.xpath("//input[@name=\"uid\"]"));
		
		userName.sendKeys(UName);
		
	}
	
	
	
	public void setPassword(String Pword) {
		
		WebElement passWord = driver.findElement(By.xpath("//input[@name=\"password\"]"));
		
		passWord.sendKeys(Pword);
	}
	
	
	
	
	public void ClickLoginButton() {
		
		WebElement LoginButton = driver.findElement(By.xpath("//input[@name=\"btnLogin\"]"));
		
		LoginButton.click();
		
	}
	

	
	
	
}

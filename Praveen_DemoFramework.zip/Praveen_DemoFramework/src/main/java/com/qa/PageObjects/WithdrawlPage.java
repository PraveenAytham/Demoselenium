package com.qa.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class WithdrawlPage {
	WebDriver driver;
	
	
	
	public WithdrawlPage(WebDriver Tcdriver) {   // constructor method
		
		driver=Tcdriver;
	
}
	
	
	
	
	
	public void clickWithdrawlTab() {
		
		WebElement WithdrawlTab = driver.findElement(By.xpath("//a[text()=\"Withdrawal\"]"));

		WithdrawlTab.click();

		driver.get("https://demo.guru99.com/V4/manager/WithdrawalInput.php");
			
	}
	
	
	
	public void EnterAccountNo(String Account) {
		
		WebElement AccountNo = driver.findElement(By.xpath("//input[@name=\"accountno\"]"));
		
		AccountNo.sendKeys(Account);
	}
	
	
	public void EnterAmount(String ammount) {
		
		WebElement Ammount = driver.findElement(By.xpath("//input[@name=\"ammount\"]"));
		
		Ammount.sendKeys(ammount);
		
	}
	
	
	
	public void EnterDescription(String desc) {
		
		WebElement Description = driver.findElement(By.xpath("//input[@name=\"desc\"]"));
		
		Description.sendKeys(desc);
				
	}
	
	
	
	public void SubmitWithdrawl() {
		
		WebElement WithdrawlSubmit = driver.findElement(By.xpath("//input[@name=\"AccSubmit\"]"));
		WithdrawlSubmit.click();
	}
	

}

package com.qa.Utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadData {
	
	String username;
	
	String password;
	
	
	
	public ReadData() {
		
		
		FileInputStream file = null;
		try {
			file = new FileInputStream(System.getProperty("user.dir")+"\\TestData\\TestDataSheet.xlsx");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Workbook workbook = null;
		try {
			workbook = WorkbookFactory.create(file);
		} catch (EncryptedDocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Sheet sheet = workbook.getSheet("Sheet1");


		 username = sheet.getRow(1).getCell(0).getStringCellValue();
		
		 password = sheet.getRow(1).getCell(1).getStringCellValue();
			
	}
	
	
	public String ExcelUsername() {
		
		return username;
	}
	
	
	public String ExcelPassword() {
		
		return password;
		
	}

}

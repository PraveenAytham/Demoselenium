package com.qa.Utilities;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReadConfig {

	String Url;
	String Username;
	String Password;
	
	
	
	
	String AccountNo;
	String Ammount;
	String Desc;

	public ReadConfig() {

		FileReader reader = null;

		try {
			reader = new FileReader(System.getProperty("user.dir")+"\\Configuration\\Config.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Properties pro = new Properties();

		try {
			pro.load(reader);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Url = pro.getProperty("URL");
		Username = pro.getProperty("UName");
		Password = pro.getProperty("Pword");
		
		AccountNo=pro.getProperty("AccountNo");
		Ammount= pro.getProperty("Ammount");
		Desc= pro.getProperty("Desc");

	}
	
	
	
	

	public String getURL() {

		return Url;

	}

	public String getUsername() {

		return Username;
	}

	public String getPassword() {

		return Password;
	}
	
	
	public String getAccountNo() {

		return AccountNo;
	}
	
	public String getAmmount() {

		return Ammount;
	}
	
	
	public String getDesc() {

		return Desc;
	}
	

}
